﻿using System;
using System.Diagnostics.Eventing.Reader;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double numLadoA, numLadoB, numLadoC;
        string Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtLadoB.Text, out numLadoB))
            {
                MessageBox.Show("Valor invalido, insira um numero");
                txtLadoB.Focus();
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtLadoC.Text, out numLadoC))
            {
                MessageBox.Show("Valor invalido, insira um numero");
                txtLadoC.Focus();
            }
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            if ((numLadoA < numLadoB + numLadoC) && (numLadoA > Math.Abs(numLadoB - numLadoC) && (Math.Abs(numLadoA - numLadoC) < numLadoB < (numLadoA + numLadoC)) && (Math.Abs(numLadoA - numLadoB) < numLadoC < (numLadoA + numLadoB))))
            {

                if (numLadoA == numLadoB) && (numLadoB == numLadoC)
                 {
                    resultado = "triângulo equilatero";
                }
                else if (numLadoA == numLadoC) || (numLadoB == numLadoC) || (numLadoB == numLadoA)
                {
                    Resultado = "triângulo isóceles";
                }
                else
                { 
                    Resultado = "triângulo escaleno"
                }
                txtResultado.Text = Resultado.ToString;
        }
private void txtLadoA_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out numLadoA))
            {
                MessageBox.Show("Valor inválido, insira um número");
                txtLadoA.Focus();
            }
        }

    }
}
